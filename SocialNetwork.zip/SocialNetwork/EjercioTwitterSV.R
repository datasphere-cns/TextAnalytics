install.packages("readr")
install.packages("xlsx")
library(rtweet)
library(tidyverse)
library(knitr)
library(tidyverse)
library(dplyr)
library(readr)
library(xlsx)

head(tweets_AFPConfia)
head(tweets_Crecer)
colnames(tweets_Crecer)

tweets_AFPConfia <- read_csv("D:/Github/Datasphere/TextAnalytics/SocialNetwork/twitter_AfpConfia.csv", col_names = TRUE)
tweets_AFPCrecer <- read_csv("D:/Github/Datasphere/TextAnalytics/SocialNetwork/twitter_AfpCrecer.csv",col_names = TRUE)
tweets_BACCredomatic <- read_csv( "D:/Github/Datasphere/TextAnalytics/SocialNetwork/twitter_BACCredomatic.csv", col_names = TRUE)
tweets_Cuscatlan <- read_csv( "D:/Github/Datasphere/TextAnalytics/SocialNetwork/twitter_Cuscatlan.csv", col_names = TRUE)
tweets_Crecer <- read_csv( "D:/Github/Datasphere/TextAnalytics/SocialNetwork/Crecer.csv", 
                           col_names = TRUE, col_types = cols(X1 = col_double(), 
                                                              X2 = col_double(), 
                                                              Name = col_character(),
                                                              Username = col_character(),
                                                              UserProfile = col_character(),
                                                              TweetID  = col_character(),
                                                              Retweets    = col_integer(),
                                                              Comments    = col_integer(),
                                                              Favorites     = col_integer(),
                                                              `IsRetweet?`     =  col_character(),
                                                              Date      =  col_datetime(),
                                                              TweetText = col_character(),
                                                              TweetSource = col_character()))




colnames(tweets_AFPConfia)
colnames(tweets_AFPCrecer)
colnames(tweets_BACCredomatic)
colnames(tweets_Cuscatlan)

str(tweets_AFPConfia)
str(tweets_AFPCrecer)
str(tweets_BACCredomatic)
str(tweets_Cuscatlan)

dim(tweets_AFPConfia)
dim(tweets_AFPCrecer)
dim(tweets_BACCredomatic)
dim(tweets_Cuscatlan)


head(tweets_AFPConfia)
head(tweets_AFPCrecer)
head(tweets_BACCredomatic)
head(tweets_Cuscatlan)


tweets_AFPConfia.dtypes

# Unimos los tweets en un ?nico dataframe
tweets2 <- bind_rows(tweets_AFPConfia,tweets_AFPCrecer, tweets_BACCredomatic, tweets_Cuscatlan)
tweets2 %>% group_by(Username) %>% summarise(numero_tweets = n())


# Aplicando transformaciones.
tweets_AFPConfia <- read_csv("D:/Github/Datasphere/TextAnalytics/SocialNetwork/twitter_AfpConfia.csv", 
                             col_names = TRUE, col_types = cols(X1 = col_double(), 
                                                                X2 = col_double(), 
                                                                Name = col_character(),
                                                                Username = col_character(),
                                                                UserProfile = col_character(),
                                                                TweetID  = col_character(),
                                                                Retweets    = col_integer(),
                                                                Comments    = col_integer(),
                                                                Favorites     = col_integer(),
                                                                `IsRetweet?`     =  col_character(),
                                                                Date      =  col_datetime(),
                                                                TweetText = col_character(),
                                                                TweetSource = col_character()))
tweets_AFPConfia <- cbind(tweets_AFPConfia, account= c("AFPConfia"))
head(tweets_AFPConfia)
str(tweets_AFPConfia)
dim(tweets_AFPConfia)

tweets_AFPCrecer <- read_csv("D:/Github/Datasphere/TextAnalytics/SocialNetwork/twitter_AfpCrecer.csv",
                             col_names = TRUE, col_types = cols(X1 = col_double(), 
                                                                X2 = col_double(), 
                                                                Name = col_character(),
                                                                Username = col_character(),
                                                                UserProfile = col_character(),
                                                                TweetID  = col_character(),
                                                                Retweets    = col_integer(),
                                                                Comments    = col_integer(),
                                                                Favorites     = col_integer(),
                                                                `IsRetweet?`     =  col_character(),
                                                                Date      =  col_datetime(),
                                                                TweetText = col_character(),
                                                                TweetSource = col_character()))
tweets_AFPConfia <- cbind(tweets_AFPConfia, account= c("AFPCrecer"))
head(tweets_AFPCrecer)
str(tweets_AFPCrecer)
dim(tweets_AFPCrecer)


tweets_BACCredomatic <- read_csv( "D:/Github/Datasphere/TextAnalytics/SocialNetwork/twitter_BACCredomatic.csv", 
                                  col_names = TRUE, col_types = cols(X1 = col_double(), 
                                                                     X2 = col_double(), 
                                                                     Name = col_character(),
                                                                     Username = col_character(),
                                                                     UserProfile = col_character(),
                                                                     TweetID  = col_character(),
                                                                     Retweets    = col_integer(),
                                                                     Comments    = col_integer(),
                                                                     Favorites     = col_integer(),
                                                                     `IsRetweet?`     =  col_character(),
                                                                     Date      =  col_datetime(),
                                                                     TweetText = col_character(),
                                                                     TweetSource = col_character()))
tweets_BACCredomatic <- cbind(tweets_AFPConfia, account= c("BacCredomatic"))
head(tweets_BACCredomatic)
str(tweets_BACCredomatic)
dim(tweets_BACCredomatic)


tweets_Cuscatlan <- read_csv( "D:/Github/Datasphere/TextAnalytics/SocialNetwork/twitter_Cuscatlan.csv", 
                              col_names = TRUE, col_types = cols(X1 = col_double(), 
                                                                 X2 = col_double(), 
                                                                 Name = col_character(),
                                                                 Username = col_character(),
                                                                 UserProfile = col_character(),
                                                                 TweetID  = col_character(),
                                                                 Retweets    = col_integer(),
                                                                 Comments    = col_integer(),
                                                                 Favorites     = col_integer(),
                                                                 `IsRetweet?`     =  col_character(),
                                                                 Date      =  col_datetime(),
                                                                 TweetText = col_character(),
                                                                 TweetSource = col_character()))


tweets_Cuscatlan <- cbind(tweets_AFPConfia, account= c("Cuscatlan"))
head(tweets_AFPConfia)
head(tweets_AFPCrecer)
head(tweets_BACCredomatic)
head(tweets_Cuscatlan)



# Unimos los tweets en un unico dataframe
tweets2 <- bind_rows(tweets_AFPConfia, tweets_BACCredomatic, tweets_Cuscatlan)
tweets2 %>% group_by(Username) %>% summarise(numero_tweets = n()) 
tweets2 %>% group_by(account) %>% summarise(numero_tweets = n()) 
head(tweets2)
dim(tweets2)


